import { useEffect, useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { api } from '../api/axios'
import { useAuth } from '../store/auth'
import ArticleCard from '../components/ArticleCard'

export default function MyWorks(){
  const nav = useNavigate()
  const { user } = useAuth() || {}
  const [items, setItems] = useState([])
  const [q, setQ] = useState('')

  async function load(){
    const url = (user?.role === 'mentor') ? '/articles' : '/articles/mine'
    const r = await api.get(url)
    setItems(r.data || [])
  }
  useEffect(()=>{ load() }, [user?.role])

  async function del(id){
    if(user?.role !== 'author') return
    if(!confirm('Delete this article?')) return
    await api.delete('/articles/'+id)
    load()
  }

  const filtered = items.filter(a=>{
    const qq = (q||'').trim().toLowerCase()
    if(!qq) return true
    const title = (a.title||'').toLowerCase()
    const authors = (a.authorsText||'').toLowerCase()
    return title.includes(qq) || authors.includes(qq)
  })

  return (
    <div className="container">
      <div className="row" style={{justifyContent:'space-between'}}>
        <div className="row" style={{gap:8, flex:1}}>
          <input className="input" placeholder="Search by title or authors..." value={q} onChange={e=>setQ(e.target.value)} />
          
        </div>
        {user?.role==='author' && <Link className="btn" to="/submit">Add</Link>}
      </div>

      {filtered.map(a=>{
        const canEdit = user?.role==='author' && (a.status==='submitted' || a.status==='rejected')
        const actions = (user?.role==='author')
          ? (<div className="row" style={{gap:8}}>
              {canEdit && <button className="btn" onClick={()=>nav('/edit/'+a._id)}>Edit</button>}
              <button className="btn danger" onClick={()=>del(a._id)}>Delete</button>
            </div>)
          : null
        return <ArticleCard key={a._id} a={a} actions={actions} />
      })}
    </div>
  )
}
