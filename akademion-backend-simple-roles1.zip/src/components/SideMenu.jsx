import { useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../store/auth'

export default function SideMenu(){
  const [open,setOpen]=useState(false)
  const { user } = useAuth() || {}
  const loc = useLocation()

  useEffect(()=>{
    const h = ()=> setOpen(o=>!o)
    window.addEventListener('toggle-sidemenu', h)
    return ()=> window.removeEventListener('toggle-sidemenu', h)
  },[])

  // Close on route change & toggle a body class for layout shift on desktop
  useEffect(()=>{ setOpen(false) }, [loc.pathname])
  useEffect(()=>{
    if(open) document.body.classList.add('sidemenu-open')
    else document.body.classList.remove('sidemenu-open')
  }, [open])

  if(!user) return null

  const isActive = (path)=> loc.pathname.startsWith(path)

  return (
    <aside className={'sidemenu'+(open?' open':'')}>
      <nav>
        <Link to="/profile" className={isActive('/profile')?'active':''}>Profil</Link>
        <Link to="/my-works" className={isActive('/my-works')?'active':''}>Sylabusy</Link>
      </nav>
    </aside>
  )
}